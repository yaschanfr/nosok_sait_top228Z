#!/usr/bin/env python3
"""
Sock Paint - Приложение для рисования на носках в стиле Paint
"""

import sys
import numpy as np
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                            QHBoxLayout, QPushButton, QSlider, QLabel, QColorDialog,
                            QFileDialog, QMessageBox, QFrame, QButtonGroup, QToolButton)
from PyQt6.QtCore import Qt, QPoint, QRect
from PyQt6.QtGui import (QPainter, QPen, QColor, QPixmap, QPainterPath, 
                         QRadialGradient, QLinearGradient, QIcon)
from PyQt6.QtPrintSupport import QPrintDialog, QPrinter

class SockCanvas(QWidget):
    """Холст для рисования на носке"""
    
    def __init__(self):
        super().__init__()
        self.setMinimumSize(400, 500)
        self.setMaximumSize(600, 700)
        
        # Настройки рисования по умолчанию
        self.brush_color = QColor(0, 0, 0)  # Черный цвет
        self.brush_size = 5
        self.eraser_size = 10
        self.current_tool = "brush"  # brush, eraser
        
        # Инициализация изображения
        self.canvas = QPixmap(self.size())
        self.canvas.fill(Qt.GlobalColor.white)
        
        # Рисуем текстуру носка
        self.draw_sock_texture()
        
        self.last_point = QPoint()
        self.drawing = False

    def draw_sock_texture(self):
        """Рисуем текстуру носка (резинку и пятку)"""
        painter = QPainter(self.canvas)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Резинка (верхняя часть)
        rubber_band = QLinearGradient(0, 0, 0, 40)
        rubber_band.setColorAt(0, QColor(240, 240, 240, 150))
        rubber_band.setColorAt(1, QColor(255, 255, 255, 0))
        
        painter.fillRect(0, 0, self.width(), 40, rubber_band)
        
        # Линия резинки
        painter.setPen(QPen(QColor(200, 200, 200, 100), 2))
        for x in range(0, self.width(), 4):
            painter.drawLine(x, 40, x + 2, 40)
        
        # Пятка (округлая область)
        heel_gradient = QRadialGradient(
            self.width() - 50, self.height() - 50, 100,
            self.width() - 50, self.height() - 50
        )
        heel_gradient.setColorAt(0, QColor(230, 230, 230, 50))
        heel_gradient.setColorAt(1, QColor(255, 255, 255, 0))
        
        painter.setBrush(heel_gradient)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(
            self.width() - 150, self.height() - 150, 
            200, 200
        )
        
        painter.end()

    def paintEvent(self, event):
        """Отрисовка виджета"""
        painter = QPainter(self)
        painter.drawPixmap(self.rect(), self.canvas)

    def mousePressEvent(self, event):
        """Обработка нажатия мыши"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.drawing = True
            self.last_point = event.position().toPoint()

    def mouseMoveEvent(self, event):
        """Обработка движения мыши"""
        if (event.buttons() & Qt.MouseButton.LeftButton) and self.drawing:
            painter = QPainter(self.canvas)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            
            if self.current_tool == "brush":
                painter.setPen(QPen(self.brush_color, self.brush_size, 
                                  Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, 
                                  Qt.PenJoinStyle.RoundJoin))
            else:  # eraser
                painter.setPen(QPen(Qt.GlobalColor.white, self.eraser_size, 
                                  Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, 
                                  Qt.PenJoinStyle.RoundJoin))
            
            current_point = event.position().toPoint()
            painter.drawLine(self.last_point, current_point)
            self.last_point = current_point
            
            self.update()

    def mouseReleaseEvent(self, event):
        """Обработка отпускания мыши"""
        if event.button() == Qt.MouseButton.LeftButton:
            self.drawing = False

    def clear_canvas(self):
        """Очистка холста"""
        reply = QMessageBox.question(
            self, "Новый носок", 
            "Начать с чистого носка? Весь рисунок будет удален.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            self.canvas.fill(Qt.GlobalColor.white)
            self.draw_sock_texture()
            self.update()

    def save_drawing(self):
        """Сохранение рисунка"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Сохранить рисунок", "",
            "PNG Images (*.png);;JPEG Images (*.jpg *.jpeg);;All Files (*)"
        )
        
        if file_path:
            self.canvas.save(file_path)
            QMessageBox.information(self, "Успех", "Рисунок сохранен!")

    def print_drawing(self):
        """Печать рисунка"""
        printer = QPrinter()
        dialog = QPrintDialog(printer, self)
        
        if dialog.exec() == QPrintDialog.DialogCode.Accepted:
            painter = QPainter(printer)
            rect = painter.viewport()
            size = self.canvas.size()
            size.scale(rect.size(), Qt.AspectRatioMode.KeepAspectRatio)
            painter.setViewport(rect.x(), rect.y(), size.width(), size.height())
            painter.setWindow(self.canvas.rect())
            painter.drawPixmap(0, 0, self.canvas)
            painter.end()

class ColorButton(QPushButton):
    """Кнопка выбора цвета"""
    
    def __init__(self, color):
        super().__init__()
        self.color = color
        self.setFixedSize(30, 30)
        self.setStyleSheet(f"background-color: {color}; border: 1px solid #888;")
        self.setCursor(Qt.CursorShape.PointingHandCursor)

class SockPaintApp(QMainWindow):
    """Главное окно приложения"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Sock Paint - Рисование на носках")
        self.setGeometry(100, 100, 800, 700)
        
        self.init_ui()
        
    def init_ui(self):
        """Инициализация интерфейса"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QVBoxLayout(central_widget)
        
        # Панель инструментов
        tool_layout = QHBoxLayout()
        
        # Кнопки инструментов
        self.brush_btn = QToolButton()
        self.brush_btn.setText("Кисть")
        self.brush_btn.setCheckable(True)
        self.brush_btn.setChecked(True)
        self.brush_btn.clicked.connect(self.set_brush_tool)
        
        self.eraser_btn = QToolButton()
        self.eraser_btn.setText("Ластик")
        self.eraser_btn.setCheckable(True)
        self.eraser_btn.clicked.connect(self.set_eraser_tool)
        
        # Группа кнопок инструментов
        self.tool_group = QButtonGroup(self)
        self.tool_group.addButton(self.brush_btn)
        self.tool_group.addButton(self.eraser_btn)
        
        # Слайдер размера кисти
        size_layout = QHBoxLayout()
        size_label = QLabel("Размер:")
        self.size_slider = QSlider(Qt.Orientation.Horizontal)
        self.size_slider.setRange(1, 30)
        self.size_slider.setValue(5)
        self.size_slider.valueChanged.connect(self.update_brush_size)
        self.size_value = QLabel("5")
        
        size_layout.addWidget(size_label)
        size_layout.addWidget(self.size_slider)
        size_layout.addWidget(self.size_value)
        
        # Кнопка выбора цвета
        self.color_btn = QPushButton("Выбрать цвет")
        self.color_btn.clicked.connect(self.choose_color)
        self.current_color = QLabel()
        self.current_color.setFixedSize(20, 20)
        self.current_color.setStyleSheet("background-color: black; border: 1px solid #888;")
        
        # Кнопка очистки
        clear_btn = QPushButton("Новый носок")
        clear_btn.clicked.connect(self.clear_canvas)
        
        # Кнопки сохранения и печати
        save_btn = QPushButton("Сохранить")
        save_btn.clicked.connect(self.save_canvas)
        
        print_btn = QPushButton("Печать")
        print_btn.clicked.connect(self.print_canvas)
        
        # Добавляем элементы на панель инструментов
        tool_layout.addWidget(self.brush_btn)
        tool_layout.addWidget(self.eraser_btn)
        tool_layout.addLayout(size_layout)
        tool_layout.addWidget(self.color_btn)
        tool_layout.addWidget(self.current_color)
        tool_layout.addWidget(clear_btn)
        tool_layout.addWidget(save_btn)
        tool_layout.addWidget(print_btn)
        
        # Палитра цветов
        colors_layout = QHBoxLayout()
        colors_label = QLabel("Цвета:")
        colors_layout.addWidget(colors_label)
        
        colors = [
            "#000000", "#FF0000", "#FF9900", "#FFFF00",
            "#00FF00", "#0078D7", "#0000FF", "#9900FF",
            "#FFFFFF", "#FF00FF", "#00FFFF", "#888888"
        ]
        
        for color in colors:
            color_btn = ColorButton(color)
            color_btn.clicked.connect(lambda checked, c=color: self.set_color(c))
            colors_layout.addWidget(color_btn)
        
        colors_layout.addStretch()
        
        # Холст
        self.canvas = SockCanvas()
        
        # Добавляем все в основной layout
        main_layout.addLayout(tool_layout)
        main_layout.addLayout(colors_layout)
        main_layout.addWidget(self.canvas)
        
        # Статус бар
        self.statusBar().showMessage("Готов к рисованию! Выберите инструмент и начинайте творить.")
    
    def set_brush_tool(self):
        """Установка инструмента Кисть"""
        self.canvas.current_tool = "brush"
        self.statusBar().showMessage("Инструмент: Кисть")
    
    def set_eraser_tool(self):
        """Установка инструмента Ластик"""
        self.canvas.current_tool = "eraser"
        self.statusBar().showMessage("Инструмент: Ластик")
    
    def update_brush_size(self, value):
        """Обновление размера кисти"""
        self.size_value.setText(str(value))
        self.canvas.brush_size = value
        self.canvas.eraser_size = value * 2
    
    def choose_color(self):
        """Выбор цвета через диалог"""
        color = QColorDialog.getColor()
        if color.isValid():
            self.set_color(color.name())
    
    def set_color(self, color):
        """Установка цвета"""
        self.canvas.brush_color = QColor(color)
        self.current_color.setStyleSheet(f"background-color: {color}; border: 1px solid #888;")
        self.set_brush_tool()
        self.brush_btn.setChecked(True)
    
    def clear_canvas(self):
        """Очистка холста"""
        self.canvas.clear_canvas()
    
    def save_canvas(self):
        """Сохранение рисунка"""
        self.canvas.save_drawing()
    
    def print_canvas(self):
        """Печать рисунка"""
        self.canvas.print_drawing()

def main():
    """Запуск приложения"""
    app = QApplication(sys.argv)
    
    # Стилизация приложения
    app.setStyle('Fusion')
    
    window = SockPaintApp()
    window.show()
    
    sys.exit(app.exec())

if __name__ == "__main__":
    main()